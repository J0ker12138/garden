package com.garden.po;

import java.util.Date;

public class DynamicAll {

	private Integer dynamic_id;

    private String dynamic_userid;

    private Date dynamic_date;

    private Integer dynamic_pointnum;

    private Integer dynamic_viewnum;
    
    private String dynamic_description;

    private String dynamic_image;
    
    

	public Integer getDynamic_id() {
		return dynamic_id;
	}

	public void setDynamic_id(Integer dynamic_id) {
		this.dynamic_id = dynamic_id;
	}

	public String getDynamic_userid() {
		return dynamic_userid;
	}

	public void setDynamic_userid(String dynamic_userid) {
		this.dynamic_userid = dynamic_userid;
	}

	public Date getDynamic_date() {
		return dynamic_date;
	}

	public void setDynamic_date(Date dynamic_date) {
		this.dynamic_date = dynamic_date;
	}

	public Integer getDynamic_pointnum() {
		return dynamic_pointnum;
	}

	public void setDynamic_pointnum(Integer dynamic_pointnum) {
		this.dynamic_pointnum = dynamic_pointnum;
	}

	public Integer getDynamic_viewnum() {
		return dynamic_viewnum;
	}

	public void setDynamic_viewnum(Integer dynamic_viewnum) {
		this.dynamic_viewnum = dynamic_viewnum;
	}

	public String getDynamic_description() {
		return dynamic_description;
	}

	public void setDynamic_description(String dynamic_description) {
		this.dynamic_description = dynamic_description;
	}

	public String getDynamic_image() {
		return dynamic_image;
	}

	public void setDynamic_image(String dynamic_image) {
		this.dynamic_image = dynamic_image;
	}

}