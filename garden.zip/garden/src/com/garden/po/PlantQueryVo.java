package com.garden.po;

import java.util.List;

public class PlantQueryVo {
    private Plant plant;
    private String collect;
	public String getCollect() {
		return collect;
	}

	public void setCollect(String collect) {
		this.collect = collect;
	}

	public Plant getPlant() {
		return plant;
	}

	public void setPlant(Plant plant) {
		this.plant = plant;
	}
    
}